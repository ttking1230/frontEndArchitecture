## Template Explorer

Live explorer for template compilation output.

To run:

- `npm run dev-compiler` in repo root
- When the compilation is done, in another terminal run `npm run open`

Note: `index.html` uses CDN for dependencies and is continuously deployed at [https://vue-next-template-explorer.netlify.com/](https://vue-next-template-explorer.netlify.com/). For local development, use the scripts above.
