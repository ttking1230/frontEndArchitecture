module.exports = require('@vue/server-renderer')
