strictmode 是什么？
alex
程序员时间管理就是没有聊妹
***
react.createElement
我有胖胖肚子。
所以要买本小猪的时间管理学
一江西流
 好好听课吧
口头减肥
IG 和 TES  1 ： 2
明天回火星____
用create-react-app生成的项目吗
一江西流
是的
🌰是Peppa啊
老师这个视频会录制下来吗？
🌰是Peppa啊
有助教吗？
薛子
老师这个视频会录制下来吗？
我本善良
今天讲了一天吗？刚来听 公开课？
平凡之路
jsx=>js 用的就是AST转换 babel ast
和ast很像
薛子
今天 又晚听了10分钟
alex
刚刚开始讲
在路上
正菜刚开始
其实都没有
刚开始 别逼逼了
DBCdouble
错了吧
苍狼
为啥要删除
DBCdouble
Children位置
sukilris
为了减少干扰  方便你理解
其实都没有
能不能好好听课??  上一句刚解释完 下一句就是为什么?
sukilris
无
一江西流
没有问题
正心
666
苍狼
删除那，没懂
苍狼:删除那，没懂



一江西流
没有问题
正心
666
苍狼
删除那，没懂
鲜于伯德
C1，C2展开看一下啥样
范义辉
@babel/preset-react吗
明天回火星____
过于低级的问题别问了，记下来下去百度，学习是需要多次的，不是一次成大师
Li。
为什么C1和C2的type是div？不是已经自定义了文本节点的type了吗
苍狼
哦，明白了
dragon
苍狼无处不在

======================
老师打开一下那个scheduleRoot页面
嘀哩哩🍒
看一下
慕
回音 what？
黄小桃
刚才说的阶段1，render，这个阶段的输出结果是是什么，是之前说的effects么？
pooh
deadline.timeRemaing 是当前侦的剩余时间吗？
嘉 华
。。。。。
牛顿丶
我这边听的有回音
嘀哩哩🍒
代码
口头减肥
虚拟dom  ->  fiber -> fiber调度（requsetIdlecallback） ?
dongjiucheng
我这面没画面了
一江西流
@pooh是的
☀_☀
这个 根组件是指 render那里的组件，还是 改变了属性的组件是根组件
Orime小潴*o*
盲猜阶段1输出diff后的dom结构也就是fiber结构