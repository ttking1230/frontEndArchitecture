## 1.课程安排
- 今天明天8点到10点 ，一共是2天的课程
- 今天会讲一些基础 刷新 rAF requestIdleCallback MessageChannel 链表 fiber fiber是如何遍历的 如何渲染的
- 明天我们从零实现 React  Fiber+hooks 来实现

## 2.屏幕刷新
- 60次/秒
- 动画或者 绘制 要求频率和设备刷新率保持一致