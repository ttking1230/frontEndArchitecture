import { DirectiveTransform } from '../transform'

export const noopDirectiveTransform: DirectiveTransform = () => ({ props: [] })
